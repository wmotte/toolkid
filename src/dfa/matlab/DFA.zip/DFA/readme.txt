The referrenced paper is attached here.
DATA1.mat contains the sample data of Weierstrass function of length 5000 between 0 to 1 of dimension 1.75



after setting the current directory and loading the sampled data in matlab,in command window,input:

 [D,Alpha]=DFA_main(DATA1)
 
which gives the dimension and alpha(Estimated scaling exponent) of the time series DATA1.

Made by:Guan Wenye
contact:guanwenye@tju.edu.cn

